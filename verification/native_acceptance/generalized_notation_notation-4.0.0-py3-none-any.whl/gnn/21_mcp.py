#!/usr/bin/env python3
"""
Step 21: MCP Processing (Thin Orchestrator)

This step orchestrates Model Context Protocol processing for GNN models.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/mcp/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the mcp module.

Pipeline Flow:
    main.py → 21_mcp.py (this script) → mcp/ (modular implementation)

How to run:
  uv run python src/gnn/21_mcp.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - MCP processing results in the specified output directory
  - Comprehensive MCP reports and summaries
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that mcp dependencies are installed
  - Check that src/gnn/mcp/ contains mcp modules
  - Check that the output directory is writable
  - Verify mcp configuration and requirements
"""

from typing import cast

# Hard import: mcp is a core module and must always be available.
from gnn.mcp import process_mcp
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "21_mcp.py",
    process_mcp,
    "Model Context Protocol processing for GNN models",
)


def main() -> int:
    """Main entry point for the mcp step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
