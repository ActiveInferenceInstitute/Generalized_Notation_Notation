"""
Intelligent Analysis MCP Integration

This module exposes intelligent analysis processing tools via MCP.
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Import utilities from the intelligent_analysis module
from gnn.utils.mcp.dispatch import run_pipeline_step_mcp, run_tool_envelope

from . import (
    FEATURES,
    check_intelligent_analysis_tools,
    get_module_info,
    get_supported_analysis_types,
    process_intelligent_analysis,
)

# MCP Tools for Intelligent Analysis Module


def process_intelligent_analysis_mcp(
    target_directory: str,
    output_directory: str,
    verbose: bool = False,
    analysis_types: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Process intelligent analysis for pipeline results. Exposed via MCP.

    Args:
        target_directory: Directory containing pipeline results to analyze
        output_directory: Directory to save analysis results
        verbose: Enable verbose output
        analysis_types: Comma-separated list of analysis types (optional)

    Returns:
        Dictionary with operation status and results.
    """
    step_kwargs: dict[str, Any] = {"logger": logger}
    if analysis_types:
        step_kwargs["analysis_types"] = analysis_types.split(",")
    return run_pipeline_step_mcp(
        process_intelligent_analysis,
        wrapper_name="process_intelligent_analysis_mcp",
        logger=logger,
        target_directory=target_directory,
        output_directory=output_directory,
        verbose=verbose,
        extra_step_kwargs=step_kwargs,
        label="Intelligent analysis",
        failure_wording="failed",
    )


def get_analysis_capabilities_mcp() -> Dict[str, Any]:
    """
    Get intelligent analysis capabilities and available tools.

    Returns the full module info, all supported analysis types, tool
    availability status, and active feature flags.

    Returns:
        Dictionary with capabilities, analysis types, and feature inventory.
    """
    return run_tool_envelope(
        lambda: {
            "success": True,
            "module_info": get_module_info(),
            "supported_analysis_types": get_supported_analysis_types(),
            "available_tools": check_intelligent_analysis_tools(),
            "features": FEATURES,
        },
        wrapper_name="get_analysis_capabilities_mcp",
        logger=logger,
    )


def get_intelligent_analysis_module_info_mcp() -> Dict[str, Any]:
    """
    Return version, feature flags, and API surface of the intelligent analysis module.

    Returns:
        Dictionary with module metadata, supported analysis types, and tool list.
    """

    def _build() -> Dict[str, Any]:
        import importlib

        mod = importlib.import_module(__package__)
        return {
            "success": True,
            "module": __package__,
            "version": getattr(mod, "__version__", "unknown"),
            "features": FEATURES,
            "supported_analysis_types": get_supported_analysis_types(),
            "tools": [
                "process_intelligent_analysis",
                "get_analysis_capabilities",
                "get_intelligent_analysis_module_info",
            ],
        }

    return run_tool_envelope(
        _build,
        wrapper_name="get_intelligent_analysis_module_info_mcp",
        logger=logger,
    )


# MCP Registration Function
def register_tools(mcp_instance: Any) -> None:
    """Register intelligent analysis domain tools with the MCP."""

    mcp_instance.register_tool(
        "process_intelligent_analysis",
        process_intelligent_analysis_mcp,
        {
            "type": "object",
            "properties": {
                "target_directory": {
                    "type": "string",
                    "description": "Directory containing pipeline results to analyze",
                },
                "output_directory": {
                    "type": "string",
                    "description": "Directory to save analysis results",
                },
                "verbose": {"type": "boolean", "default": False},
                "analysis_types": {
                    "type": "string",
                    "description": "Comma-separated analysis types (optional)",
                    "nullable": True,
                },
            },
            "required": ["target_directory", "output_directory"],
        },
        "Process AI-powered intelligent analysis of GNN pipeline results: failure analysis, performance optimization.",
        module=__package__,
        category="intelligent_analysis",
    )

    mcp_instance.register_tool(
        "get_analysis_capabilities",
        get_analysis_capabilities_mcp,
        {},
        "Get intelligent analysis capabilities, supported types, available tools, and feature flags.",
        module=__package__,
        category="intelligent_analysis",
    )

    mcp_instance.register_tool(
        "get_intelligent_analysis_module_info",
        get_intelligent_analysis_module_info_mcp,
        {},
        "Return version, feature flags, and tool inventory of the intelligent analysis module.",
        module=__package__,
        category="intelligent_analysis",
    )

    logger.info("intelligent_analysis module MCP tools registered (3 domain tools).")
