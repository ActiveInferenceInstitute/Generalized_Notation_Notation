#!/usr/bin/env python3
"""
Step 23: Report Generation (Thin Orchestrator)

This step orchestrates report generation for GNN models.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/report/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the report module.

Pipeline Flow:
    main.py → 23_report.py (this script) → report/ (modular implementation)

How to run:
  uv run python src/gnn/23_report.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - Report generation results in the specified output directory
  - Comprehensive report summaries
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that report dependencies are installed
  - Check that src/gnn/report/ contains report modules
  - Check that the output directory is writable
  - Verify report configuration and requirements
"""

from typing import cast

from gnn.report import process_report
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "23_report.py",
    process_report,
    "Report generation for GNN models",
)


def main() -> int:
    """Main entry point for the report step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
