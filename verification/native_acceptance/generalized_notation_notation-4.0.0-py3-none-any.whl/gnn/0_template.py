#!/usr/bin/env python3
"""
Step 0: Pipeline Template with Infrastructure Demonstration (Thin Orchestrator)

This step demonstrates the thin orchestrator pattern in the GNN pipeline architecture.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/template/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the template module.

Pipeline Flow:
    main.py → 0_template.py (this script) → template/ (modular implementation)

How to run:
  uv run python src/gnn/0_template.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - Template processing results in the specified output directory
  - Infrastructure demonstration and pattern validation
  - Comprehensive error handling and recovery demonstrations
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that template dependencies are installed
  - Check that src/gnn/template/ contains template modules
  - Check that the output directory is writable
  - Verify template configuration and pattern setup
"""

from typing import cast

from gnn.template import process_template_standardized
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "0_template.py",
    process_template_standardized,
    "Pipeline template and infrastructure demonstration",
    additional_arguments={
        "simulate_error": {"type": bool, "help": "Simulate an error for testing"}
    },
)


def main() -> int:
    """Main entry point for the template step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
