"""
MCP integration for the SAPF (Sound As Pure Form) audio synthesis submodule.

Exposes SAPF audio generation tools: audio synthesis from GNN models,
audio artifact inventory, and module metadata through MCP. Discovered by the
MCP server through the parent ``gnn.audio.mcp`` registration hook
(``MCP.discover_modules`` scans only top-level ``src/gnn/*/mcp.py`` files).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

from gnn.utils.mcp.dispatch import run_tool_envelope

from . import get_module_info as _get_mod_info
from . import process_gnn_to_audio

logger = logging.getLogger(__name__)


def process_sapf_mcp(
    target_directory: str, output_directory: str, verbose: bool = False
) -> Dict[str, Any]:
    """
    Generate SAPF audio from GNN model files.

    Converts GNN probabilistic model structure into SAPF (SuperCollider Audio Program
    Format) audio synthesis code and produces audio artifacts.

    Args:
        target_directory: Directory containing GNN files to convert to audio
        output_directory: Directory to save generated audio files and SAPF scripts
        verbose: Enable verbose logging

    Returns:
        Dictionary with success status and audio generation summary.
    """

    def _build() -> Dict[str, Any]:
        out_dir = Path(output_directory)
        out_dir.mkdir(parents=True, exist_ok=True)
        target_dir = Path(target_directory)
        gnn_files = sorted(target_dir.rglob("*.md"))
        results: list[Dict[str, Any]] = []
        for gnn_file in gnn_files:
            content = gnn_file.read_text(encoding="utf-8")
            results.append(
                process_gnn_to_audio(
                    content,
                    gnn_file.stem,
                    str(out_dir),
                    validate_only=False,
                )
            )
        success = bool(gnn_files) and all(
            bool(result.get("success")) for result in results
        )
        audio_files = (
            list(out_dir.rglob("*.wav"))
            + list(out_dir.rglob("*.aiff"))
            + list(out_dir.rglob("*.sc"))
        )
        return {
            "success": success,
            "target_directory": target_directory,
            "output_directory": output_directory,
            "models_processed": len(results),
            "audio_files_generated": len(audio_files),
            "message": f"SAPF audio generation {'completed successfully' if success else 'completed with issues'}",
        }

    return run_tool_envelope(
        _build,
        wrapper_name="process_sapf_mcp",
        logger=logger,
    )


def get_sapf_module_info_mcp() -> Dict[str, Any]:
    """
    Return metadata about the SAPF audio module.

    Returns:
        Dictionary with version, capabilities, and supported audio formats.
    """
    try:
        info = _get_mod_info()
        return {"success": True, **info}
    except Exception as e:
        logger.error(f"get_sapf_module_info_mcp error: {e}", exc_info=True)
        return {
            "success": True,
            "module": "sapf",
            "description": "SAPF audio synthesis from GNN Active Inference models",
            "supported_formats": ["wav", "aiff", "sc (SuperCollider)"],
            "note": str(e),
        }


def list_audio_artifacts_mcp(output_directory: str) -> Dict[str, Any]:
    """
    List audio and SAPF script artifacts in an output directory.

    Args:
        output_directory: Directory containing generated audio files

    Returns:
        Dictionary with audio file inventory and format counts.
    """

    def _build() -> Dict[str, Any]:
        out_dir = Path(output_directory)
        if not out_dir.exists():
            return {
                "success": False,
                "error": f"Directory not found: {output_directory}",
            }

        artifacts: List[Dict[str, Any]] = []
        for ext in ["*.wav", "*.aiff", "*.mp3", "*.ogg", "*.sc", "*.scd"]:
            for f in sorted(out_dir.rglob(ext)):
                artifacts.append(
                    {
                        "name": f.name,
                        "type": f.suffix.lstrip("."),
                        "size_bytes": f.stat().st_size,
                        "path": str(f.relative_to(out_dir)),
                    }
                )

        by_type: Dict[str, int] = {}
        for a in artifacts:
            by_type[a["type"]] = by_type.get(a["type"], 0) + 1

        return {
            "success": True,
            "output_directory": str(out_dir),
            "total_artifacts": len(artifacts),
            "by_type": by_type,
            "artifacts": artifacts,
        }

    return run_tool_envelope(
        _build,
        wrapper_name="list_audio_artifacts_mcp",
        logger=logger,
    )


# ── MCP Registration ────────────────────────────────────────────────────────


def register_tools(mcp_instance: Any) -> None:
    """Register SAPF audio tools with the MCP server."""

    mcp_instance.register_tool(
        "process_sapf",
        process_sapf_mcp,
        {
            "type": "object",
            "properties": {
                "target_directory": {
                    "type": "string",
                    "description": "Directory with GNN files to convert to audio",
                },
                "output_directory": {
                    "type": "string",
                    "description": "Directory for audio and SAPF script outputs",
                },
                "verbose": {"type": "boolean", "default": False},
            },
            "required": ["target_directory", "output_directory"],
        },
        "Generate SAPF audio from GNN Active Inference models using SuperCollider synthesis.",
        module=__package__,
        category="audio",
    )

    mcp_instance.register_tool(
        "get_sapf_module_info",
        get_sapf_module_info_mcp,
        {},
        "Return metadata about the SAPF audio synthesis module (version, formats, capabilities).",
        module=__package__,
        category="audio",
    )

    mcp_instance.register_tool(
        "list_audio_artifacts",
        list_audio_artifacts_mcp,
        {
            "type": "object",
            "properties": {
                "output_directory": {
                    "type": "string",
                    "description": "Directory with generated audio files",
                },
            },
            "required": ["output_directory"],
        },
        "List audio and SAPF script artifacts in an output directory.",
        module=__package__,
        category="audio",
    )

    logger.info("sapf module MCP tools registered (3 tools).")
