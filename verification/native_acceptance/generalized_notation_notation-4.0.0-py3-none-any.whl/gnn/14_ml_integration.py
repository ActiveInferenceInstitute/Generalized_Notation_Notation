#!/usr/bin/env python3
"""
Step 14: ML Integration Processing (Thin Orchestrator)

This step orchestrates ML integration processing for GNN models.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/ml_integration/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the ml_integration module.

Pipeline Flow:
    main.py → 14_ml_integration.py (this script) → ml_integration/ (modular implementation)

How to run:
  uv run python src/gnn/14_ml_integration.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - ML integration processing results in the specified output directory
  - Comprehensive ml_integration reports and summaries
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that ml_integration dependencies are installed
  - Check that src/gnn/ml_integration/ contains ml_integration modules
  - Check that the output directory is writable
  - Verify ml_integration configuration and requirements
"""

from typing import cast

from gnn.ml_integration import process_ml_integration
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "14_ml_integration.py",
    process_ml_integration,
    "ML integration processing for GNN models",
)


def main() -> int:
    """Main entry point for the ml_integration step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
