#!/usr/bin/env python3
"""
Step 22: GUI Processing (Thin Orchestrator)

This step orchestrates GUI processing for GNN models.
Provides multiple interactive GUI implementations and headless artifact generation.

Available GUI Options:
    - gui_1: Form-based Interactive GNN Constructor (Port 7860)
    - gui_2: Visual Matrix Editor (Port 7861)
    - gui_3: State Space Design Studio (Port 7862)
    - oxdraw: Visual diagram-as-code interface with Mermaid (Port 5151)

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/gui/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the gui module.

Pipeline Flow:
    main.py → 22_gui.py (this script) → gui/ (modular implementation)

How to run:
  # Headless mode (pipeline default - generates artifacts only)
  uv run python src/gnn/22_gui.py --target-dir input/gnn_files --output-dir output --headless

  # Interactive mode (launch GUI servers)
  uv run python src/gnn/22_gui.py --target-dir input/gnn_files --output-dir output --interactive

  # Specific GUI types
  uv run python src/gnn/22_gui.py --gui-types "gui_1,oxdraw" --interactive

  # As part of pipeline (automatically runs in headless mode)
  uv run python src/gnn/main.py  # runs all steps including GUI in headless mode

Expected outputs:
  - GUI artifacts in output/22_gui_output/ (headless mode)
  - Running GUI servers on ports 7860-7862, 5151 (interactive mode)
  - gui_processing_summary.json with execution status
  - Constructed/designed GNN models in markdown format
  - GUI status and metadata files

If you encounter errors:
  - Check that Gradio is installed: uv pip install -e .[gui]
  - Check that src/gnn/gui/ contains GUI modules
  - Check that the output directory is writable
  - For interactive mode, ensure ports 7860-7862, 5151 are available
  - Verify GUI dependencies (gradio, plotly, numpy, pandas)
  - For oxdraw: Install with `cargo install oxdraw` (optional for headless mode)
"""

from typing import cast

from gnn.gui import process_gui
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "22_gui.py",
    process_gui,
    "GUI processing for GNN models (Interactive Constructor)",
    additional_arguments={
        "headless": {
            "action": "store_true",
            "default": False,  # Will be set to True in process_gui if not --interactive
            "help": "Run in headless mode (artifacts only, no GUI servers)",
        },
        "interactive": {
            "action": "store_true",
            "default": False,
            "help": "Launch interactive GUI servers (overrides headless)",
        },
        "gui_types": {
            "type": str,
            "default": "gui_1,gui_2",
            "help": "Comma-separated list of GUI types to run (gui_1, gui_2, gui_3, oxdraw)",
        },
        "open_browser": {
            "action": "store_true",
            "default": False,
            "help": "Automatically open browser for interactive GUIs",
        },
        "launch_editor": {
            "action": "store_true",
            "default": False,
            "help": "Launch oxdraw editor (interactive oxdraw GUI type)",
        },
    },
)


def main() -> int:
    """Main entry point for the GUI step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
