#!/usr/bin/env python3
"""
Step 16: Analysis Processing (Thin Orchestrator)

This step orchestrates analysis processing for GNN models.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/analysis/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the analysis module.

Pipeline Flow:
    main.py → 16_analysis.py (this script) → analysis/ (modular implementation)

How to run:
  uv run python src/gnn/16_analysis.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - Analysis processing results in the specified output directory
  - Comprehensive analysis reports and summaries
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that analysis dependencies are installed
  - Check that src/gnn/analysis/ contains analysis modules
  - Check that the output directory is writable
  - Verify analysis configuration and requirements
"""

from typing import cast

from gnn.analysis import process_analysis
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "16_analysis.py",
    process_analysis,
    "Analysis processing for GNN models",
    additional_arguments={
        "advanced_stats": {
            "flag": "--advanced-stats",
            "action": "store_true",
            "help": "Enable advanced statistical distributions and extended visualizations",
        },
        "generate_animations": {
            "flag": "--no-animations",
            "action": "store_false",
            "default": True,
            "dest": "generate_animations",
            "help": "Disable Step 16 GridWorld GIF animation artifacts (enabled by default)",
        },
    },
)


def main() -> int:
    """Main entry point for the analysis step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
