"""
oxdraw Processor - Main orchestration logic for GNN-oxdraw integration

Handles:
- GNN file discovery and conversion to Mermaid
- oxdraw editor launching (interactive mode)
- Mermaid to GNN conversion (headless mode)
- Validation and error handling
"""

import json
import logging
import shutil
import subprocess  # nosec B404
from pathlib import Path
from typing import Any, Dict, Optional

from gnn.gui.websocket_bridge import build_initial_messages
from gnn.processing.processor import discover_gnn_files

from ..backend import write_json_atomically
from .mermaid_converter import convert_gnn_file_to_mermaid
from .mermaid_parser import convert_mermaid_file_to_gnn
from .utils import validate_mermaid_syntax


def process_oxdraw(
    target_dir: Path,
    output_dir: Path,
    logger: logging.Logger,
    mode: str = "headless",
    auto_convert: bool = True,
    validate_on_save: bool = True,
    launch_editor: bool = False,
    port: int = 5151,
    host: str = "127.0.0.1",
    **kwargs: Any,
) -> bool:
    """
    Process GNN files through oxdraw visual interface.

    Args:
        target_dir: Directory containing GNN files
        output_dir: Output directory for oxdraw results
        logger: Logger instance for progress reporting
        mode: "interactive" or "headless" (default: headless for pipeline)
        auto_convert: Automatically convert GNN files to Mermaid
        validate_on_save: Validate models when converting back from Mermaid
        launch_editor: Launch oxdraw editor (only if mode=interactive)
        port: Port for oxdraw server
        host: Host for oxdraw server
        **kwargs: Additional processing options

    Returns:
        True if processing succeeded
    """
    logger.info("🎨 oxdraw Integration - Visual GNN Model Interface")
    logger.info(f"Mode: {mode}")
    logger.info(f"Target directory: {target_dir}")
    logger.info(f"Output directory: {output_dir}")

    output_dir.mkdir(parents=True, exist_ok=True)

    # Check oxdraw availability for interactive mode
    if mode == "interactive" and launch_editor:
        if not check_oxdraw_installed():
            logger.warning(
                "⚠️  oxdraw CLI not found. Install with: cargo install oxdraw"
            )
            logger.info("Falling back to headless conversion mode...")
            mode = "headless"

    # Discover GNN files
    gnn_files = discover_gnn_files(target_dir, recursive=True)
    logger.info(f"📁 Found {len(gnn_files)} GNN file(s)")

    if not gnn_files:
        logger.warning("No GNN files found to process")
        return False

    results: dict[str, Any] = {
        "mode": mode,
        "timestamp": _get_timestamp(),
        "files_processed": [str(f) for f in gnn_files],
        "gnn_to_mermaid_conversions": [],
        "mermaid_to_gnn_conversions": [],
        "websocket_bridge": {
            "enabled": False,
            "message_contract_available": True,
            "server_running": False,
            "host": host,
            "port": port,
            "messages": [],
            "status": "message_contract_only",
        },
        "errors": [],
    }

    # Phase 1: Convert GNN files to Mermaid
    if auto_convert:
        logger.info("📝 Phase 1: Converting GNN files to Mermaid format...")

        for i, gnn_file in enumerate(gnn_files, 1):
            logger.info(f"  [{i}/{len(gnn_files)}] Processing: {gnn_file.name}")

            try:
                mermaid_file = output_dir / f"{gnn_file.stem}.mmd"
                mermaid_content = convert_gnn_file_to_mermaid(gnn_file, mermaid_file)

                results["gnn_to_mermaid_conversions"].append(
                    {
                        "gnn_file": str(gnn_file),
                        "mermaid_file": str(mermaid_file),
                        "success": True,
                        "lines": len(mermaid_content.split("\n")),
                    }
                )

                logger.info(f"  ✅ Converted: {gnn_file.name} → {mermaid_file.name}")
                is_valid, validation_errors = validate_mermaid_syntax(mermaid_content)
                if not is_valid:
                    results["errors"].append(
                        {
                            "file": str(mermaid_file),
                            "phase": "mermaid_validation",
                            "error": "; ".join(validation_errors),
                        }
                    )

            except Exception as e:
                logger.error(f"  ❌ Conversion failed for {gnn_file.name}: {e}")
                results["errors"].append(
                    {"file": str(gnn_file), "phase": "gnn_to_mermaid", "error": str(e)}
                )
                results["gnn_to_mermaid_conversions"].append(
                    {"gnn_file": str(gnn_file), "success": False, "error": str(e)}
                )

    # Phase 2: Launch interactive editor or process in headless mode
    if (
        mode == "interactive"
        and launch_editor
        and results["gnn_to_mermaid_conversions"]
    ):
        logger.info("🚀 Phase 2: Launching oxdraw interactive editor...")

        # Launch editor for first successfully converted file
        first_success = next(
            (c for c in results["gnn_to_mermaid_conversions"] if c["success"]), None
        )

        if first_success:
            first_mermaid = Path(first_success["mermaid_file"])

            try:
                success = launch_oxdraw_editor(
                    mermaid_file=first_mermaid, port=port, host=host, logger=logger
                )

                if success:
                    logger.info(f"✅ oxdraw editor launched at http://{host}:{port}")
                    logger.info(
                        "Edit your model visually, then save and close the editor"
                    )

                    results["editor_launched"] = True
                    results["editor_url"] = f"http://{host}:{port}"
                else:
                    logger.warning("⚠️  Failed to launch oxdraw editor")
                    results["editor_launched"] = False

            except Exception as e:
                logger.error(f"❌ Editor launch error: {e}")
                results["errors"].append({"phase": "editor_launch", "error": str(e)})
                results["editor_launched"] = False

    # Phase 3: Convert Mermaid files back to GNN (only files produced this run)
    produced_mermaid_files = [
        Path(c["mermaid_file"])
        for c in results["gnn_to_mermaid_conversions"]
        if c.get("success") and c.get("mermaid_file")
    ]

    if validate_on_save and produced_mermaid_files:
        logger.info("🔄 Phase 3: Converting Mermaid files back to GNN...")

        for i, mermaid_file in enumerate(produced_mermaid_files, 1):
            logger.info(
                f"  [{i}/{len(produced_mermaid_files)}] Processing: {mermaid_file.name}"
            )

            try:
                output_gnn_file = output_dir / f"{mermaid_file.stem}_from_mermaid.md"
                parsed_model = convert_mermaid_file_to_gnn(
                    mermaid_file, output_gnn_file
                )

                results["mermaid_to_gnn_conversions"].append(
                    {
                        "mermaid_file": str(mermaid_file),
                        "gnn_file": str(output_gnn_file),
                        "success": True,
                        "variables": len(parsed_model.get("variables", {})),
                        "connections": len(parsed_model.get("connections", [])),
                    }
                )

                logger.info(
                    f"  ✅ Converted: {mermaid_file.name} → {output_gnn_file.name}"
                )

            except Exception as e:
                logger.error(f"  ❌ Conversion failed for {mermaid_file.name}: {e}")
                results["errors"].append(
                    {
                        "file": str(mermaid_file),
                        "phase": "mermaid_to_gnn",
                        "error": str(e),
                    }
                )
                results["mermaid_to_gnn_conversions"].append(
                    {
                        "mermaid_file": str(mermaid_file),
                        "success": False,
                        "error": str(e),
                    }
                )

    successful_payloads = []
    for conversion in results["gnn_to_mermaid_conversions"]:
        if not conversion.get("success") or not conversion.get("mermaid_file"):
            continue
        mermaid_file = Path(conversion["mermaid_file"])
        payload = {
            "model_id": mermaid_file.stem,
            "format": "mermaid",
            "gnn_file": conversion["gnn_file"],
            "mermaid_file": str(mermaid_file),
        }
        successful_payloads.append(payload)
    results["websocket_bridge"]["messages"] = [
        json.loads(message.to_json())
        for message in build_initial_messages(successful_payloads)
    ]

    # Summary
    g2m_success_count = sum(
        1 for c in results["gnn_to_mermaid_conversions"] if c["success"]
    )
    g2m_total_count = len(results["gnn_to_mermaid_conversions"])
    m2g_success_count = sum(
        1 for c in results["mermaid_to_gnn_conversions"] if c["success"]
    )
    m2g_total_count = len(results["mermaid_to_gnn_conversions"])

    results["summary"] = {
        "gnn_to_mermaid_success": g2m_success_count,
        "gnn_to_mermaid_total": g2m_total_count,
        "mermaid_to_gnn_success": m2g_success_count,
        "mermaid_to_gnn_total": m2g_total_count,
        "unexpected_failures": len(results["errors"]),
    }

    # Save processing results (atomic to avoid torn artifacts on crash)
    results_file = output_dir / "oxdraw_processing_results.json"
    write_json_atomically(results_file, results)

    logger.info(f"📊 Processing results saved to: {results_file}")

    logger.info("✨ Summary:")
    logger.info(f"   GNN → Mermaid: {g2m_success_count}/{g2m_total_count} successful")

    if results["mermaid_to_gnn_conversions"]:
        logger.info(
            f"   Mermaid → GNN: {m2g_success_count}/{m2g_total_count} successful"
        )

    if results["errors"]:
        logger.warning(f"   Errors: {len(results['errors'])}")

    return g2m_success_count > 0 and len(results["errors"]) == 0


def check_oxdraw_installed() -> bool:
    """
    Check if oxdraw CLI is installed and available.

    Returns:
        True if oxdraw is available, False otherwise
    """
    return shutil.which("oxdraw") is not None


def launch_oxdraw_editor(
    mermaid_file: Path,
    port: int = 5151,
    host: str = "127.0.0.1",
    logger: Optional[logging.Logger] = None,
    background: bool = False,
) -> bool:
    """
    Launch oxdraw interactive editor for a Mermaid file.

    Args:
        mermaid_file: Path to Mermaid file to edit
        port: Port for oxdraw server
        host: Host address for oxdraw server
        logger: Optional logger instance
        background: Run in background (non-blocking)

    Returns:
        True if launch succeeded, False otherwise
    """
    if not check_oxdraw_installed():
        if logger:
            logger.error("oxdraw CLI not found. Install with: cargo install oxdraw")
        return False

    if not mermaid_file.exists():
        if logger:
            logger.error(f"Mermaid file not found: {mermaid_file}")
        return False

    try:
        cmd: list[Any] = [
            "oxdraw",
            "--input",
            str(mermaid_file),
            "--edit",
            "--serve-host",
            host,
            "--serve-port",
            str(port),
        ]

        if logger:
            logger.info(f"Launching oxdraw: {' '.join(cmd)}")

        if background:
            # Non-blocking launch
            subprocess.Popen(  # nosec B603
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        else:
            # Blocking launch
            subprocess.run(cmd, check=True, timeout=300)  # nosec B603

        return True

    except subprocess.CalledProcessError as e:
        if logger:
            logger.error(f"oxdraw launch failed: {e}")
        return False
    except Exception as e:
        if logger:
            logger.error(f"Unexpected error launching oxdraw: {e}")
        return False


def get_module_info() -> Dict[str, Any]:
    """
    Get module information and capabilities.

    Returns:
        Dictionary with module metadata
    """
    return {
        "name": "oxdraw",
        "version": "1.0.0",
        "description": "Visual diagram-as-code interface for GNN Active Inference models",
        "capabilities": [
            "GNN to Mermaid conversion",
            "Mermaid to GNN parsing",
            "Interactive visual editing",
            "Headless batch conversion",
            "Ontology preservation",
            "Connection validation",
        ],
        "modes": ["interactive", "headless"],
        "supported_formats": ["mermaid", "gnn_markdown"],
        "oxdraw_cli_available": check_oxdraw_installed(),
    }


def _get_timestamp() -> str:
    """Get ISO 8601 timestamp."""
    from datetime import datetime

    return datetime.now().isoformat()
