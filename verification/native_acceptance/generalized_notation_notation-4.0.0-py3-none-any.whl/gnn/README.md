# GNN (Generalized Notation Notation) Core Module

Core infrastructure for GNN: file discovery, multi-format parsing, serialization,
round-trip validation, and schema / cross-format consistency checks.

## Format Interoperability Status

Canonical numbers (enum size, serializer count, round-trip scope) are defined in **[SPEC.md](SPEC.md)**.

- **`GNNFormat`**: 23 values (`parsers/common.py`).
- **Serializers**: 22 registered (`parsers/system.py`); **PNML** is parse-only in the registry sense (no dedicated serializer entry).
- **Round-trip tests**: pytest cases in [`tests/testing/test_round_trip.py`](../../tests/testing/test_round_trip.py), driven by the `gnn/testing/round_trip_tester.py` runner, exercise **markdown** plus **20** target formats (21 entries total). **EBNF** and **PNML** are outside the default round-trip list.

For the reference model used in tests, those **21** formats achieve **100%** round-trip success in that suite.

### Supported Format Categories (round-trip suite)

- **Schema**: JSON, XML, YAML, Protobuf, XSD, ASN.1, PKL (7)
- **Languages**: Python, Scala, Lean, Coq, Isabelle, Haskell (6)
- **Formal / grammar**: TLA+, Agda, Alloy, Z-notation, BNF (5); EBNF shares machinery with BNF but is not separately listed in the default round-trip config
- **Other**: Maxima, Pickle (2)
- **Reference**: Markdown (1)

## Overview

GNN enables researchers and practitioners to:

- Specify generative models in a standardized, machine-readable format
- Convert between all supported formats with semantic preservation
- Validate model specifications with multiple validation levels
- Parse and analyze model structures across different paradigms
- Export models to simulation environments (PyMDP, RxInfer.jl)
- Generate visualizations and documentation

### GNN Processing Workflow

```mermaid
graph TD
    Input[Input .md File] -->|Parser| Parsed[Parsed Model]
    Parsed -->|Schema Validator| Valid{Valid?}
    Valid -->|No| Error[Error Report]
    Valid -->|Yes| IR[Intermediate Representation]
    
    IR -->|Cross-Format Validator| Consistent{Consistent?}
    Consistent -->|No| Warn[Consistency Warning]
    Consistent -->|Yes| Serializer[Multi-Format Serializer]
    
    Serializer -->|Export| JSON[JSON]
    Serializer -->|Export| XML[XML]
    Serializer -->|Export| Python[Python]
    Serializer -->|Export| Others[Other 20+ Formats]
    
    subgraph "Validation Core"
    Parsed
    Valid
    IR
    Consistent
    end
```

### Format Conversion Architecture

```mermaid
graph LR
    subgraph "Input Formats"
        MD[Markdown]
        JSON_IN[JSON]
        XML_IN[XML]
        YAML_IN[YAML]
    end
    
    subgraph "Unified Parser"
        Parser[GNNParsingSystem]
        IR[Internal Representation]
    end
    
    subgraph "Format Serializers"
        Serializer[Format Serializers]
    end
    
    subgraph "Output Formats"
        SCALA[Scala]
        LEAN[Lean]
        COQ[Coq]
        PYTHON[Python]
        HASKELL[Haskell]
        PROTOBUF[Protobuf]
        XSD[XSD]
        ASN1[ASN.1]
        OTHERS[15+ More Formats]
    end
    
    MD --> Parser
    JSON_IN --> Parser
    XML_IN --> Parser
    YAML_IN --> Parser
    
    Parser --> IR
    IR --> Serializer
    
    Serializer --> SCALA
    Serializer --> LEAN
    Serializer --> COQ
    Serializer --> PYTHON
    Serializer --> HASKELL
    Serializer --> PROTOBUF
    Serializer --> XSD
    Serializer --> ASN1
    Serializer --> OTHERS
```

### Parser Architecture

```mermaid
graph TB
    subgraph "Parser Registry"
        Registry[GNNParsingSystem]
    end
    
    subgraph "Format Parsers"
        MarkdownP[Markdown Parser]
        JSONP[JSON Parser]
        XMLP[XML Parser]
        YAMLP[YAML Parser]
        SchemaP[Schema Parsers]
        GrammarP[Grammar Parsers]
        BinaryP[Binary Parser]
    end
    
    subgraph "Format Serializers"
        MarkdownS[Markdown Serializer]
        JSONS[JSON Serializer]
        XMLS[XML Serializer]
        YAMLS[YAML Serializer]
        ScalaS[Scala Serializer]
        LeanS[Lean Serializer]
        CoqS[Coq Serializer]
        PythonS[Python Serializer]
        OthersS[15+ More Serializers]
    end
    
    subgraph "Validation"
        SchemaV[Schema Validator]
        CrossV[Cross-Format Validator]
        RoundTrip[Round-Trip Tester]
    end
    
    Registry --> MarkdownP
    Registry --> JSONP
    Registry --> XMLP
    Registry --> YAMLP
    Registry --> SchemaP
    Registry --> GrammarP
    Registry --> BinaryP
    
    MarkdownP --> SchemaV
    JSONP --> SchemaV
    XMLP --> SchemaV
    
    SchemaV --> CrossV
    CrossV --> RoundTrip
    
    Registry --> MarkdownS
    Registry --> JSONS
    Registry --> XMLS
    Registry --> YAMLS
    Registry --> ScalaS
    Registry --> LeanS
    Registry --> CoqS
    Registry --> PythonS
    Registry --> OthersS
```

### Module Integration Flow

```mermaid
flowchart LR
    subgraph "Pipeline Step 3"
        Step3[3_gnn.py Orchestrator]
    end
    
    subgraph "GNN Module"
        MultiFormat[multi_format_processor.py]
        Processor[processor.py]
        Parser[parsers/basic.py]
        ParsingSystem[parsers/GNNParsingSystem]
    end
    
    subgraph "Downstream Steps"
        Step5[Step 5: Type Checker]
        Step6[Step 6: Validation]
        Step7[Step 7: Export]
        Step8[Step 8: Visualization]
        Step10[Step 10: Ontology]
        Step11[Step 11: Render]
    end
    
    Step3 --> MultiFormat
    MultiFormat --> Processor
    MultiFormat --> ParsingSystem
    Processor --> Parser
    
    MultiFormat -->|Parsed Models| Step6
    MultiFormat -->|Parsed Models| Step7
    MultiFormat -->|Parsed Models| Step8
    MultiFormat -->|Parsed Models| Step9
```

## Module Structure

```
src/gnn/
├── __init__.py                    # Lazy package init (PEP 562 facade: _EXPORT_MAP + __all__)
├── main.py                        # Pipeline driver: python src/gnn/main.py (run/reproduce)
├── processing/                    # Discovery/parse/orchestration engine (processor, core_processor, multi_format_processor, discovery)
├── extract/                       # Headless extraction + bridge-pinned pomdp_extractor; python -m gnn.extract FILE [--strict|--no-strict] [--compact]
├── schema/                        # Import-light section/state-space/connection parsing (bridge-pinned)
├── types/                         # Canonical domain dataclasses (ParsedGNN, GNNVariable, ValidationResult, ...)
├── manuscript/                    # Deterministic manuscript {{TOKEN}} map producer
├── 0_template.py ... 24_intelligent_analysis.py   # 25 thin step drivers (see STEP_INDEX.md)
├── README.md / SPEC.md / AGENTS.md / SKILL.md / STEP_INDEX.md
│
├── parsers/                       # Parser ecosystem (see SPEC.md for 23/22 counts)
│   ├── system.py                  # PARSER_REGISTRY / SERIALIZER_REGISTRY, GNNParsingSystem
│   ├── basic.py                   # Structural/formal parse surface (GNNFormalParser, validate_gnn_syntax)
│   ├── frontmatter.py             # YAML front-matter extraction
│   ├── unified_parser.py / common.py  # Unified entry; GNNFormat enum, protocols, shared types
│   └── *_parser.py / *_serializer.py  # Per-format parsers and serializers (23 / 22)
│
├── schema_validator/              # Syntax-level validation package
│   ├── syntax.py                  # GNNParser (regex section parser)
│   ├── validator.py               # GNNValidator (multi-level validation)
│   └── cross_format.py            # Cross-format consistency validation
│
├── multimodel/                    # Multi-model file handling
│   ├── multimodel.py              # split_models / parse_multimodel
│   └── dep_graph.py               # Inter-model dependency graphs (gnn graph)
│
├── mcp/                           # Model Context Protocol integration (see mcp/README.md)
│   ├── gnn_root.py                # GNN-module domain tools
│   ├── processors.py              # Folder/round-trip/cross-format operations
│   └── server_stdio.py / server_http.py / cli.py  # Transports and CLI
│
├── execute/                       # Step-12 executor framework: 10 families incl lean, bnlearn (execute/README.md)
├── render/                        # Step-11 renderers: 9 targets, all executed (render/README.md)
├── validation/                    # Step-6 model validation; simple.py recovery validator
├── report/                        # Report generation; processing_report.py
├── pipeline/                      # Step orchestration, config, hashing, preflight
├── api/                           # FastAPI service (gnn serve)
├── cli/                           # CLI surface (gnn = gnn.cli:main)
├── analysis/ audio/ docs/ documentation/ export/ formal_specs/ gnn_examples/ grammars/
│   gui/ integration/ intelligent_analysis/ llm/ lsp/ ml_integration/ model_registry/
│   ontology/ research/ sapf/ schemas/ security/ setup/ template/ testing/
│   type_checker/ type_systems/ utils/ visualization/ website/   # Remaining step/support packages
│
└── (repo root) input/gnn_files/   # Pipeline input examples; tests often use
                                   # input/gnn_files/discrete/actinf_pomdp_agent.md

## Headless Extraction

`gnn/extract.py` is a stdlib-only headless entry point for machine-readable
extraction of a POMDP state space from a GNN file:

```bash
python -m gnn.extract input/gnn_files/discrete/actinf_pomdp_agent.md --strict
```

- Success prints the `POMDPStateSpace.to_dict()` payload as JSON (exit 0);
  `--compact` emits compact JSON.
- Failure prints `{"status": "error", "error": {"code", "message", "line", "section"}}`
  (exit 1). Codes come from the extractor's structured errors (`GNN-E002`
  shape/orientation, `GNN-E006` parameter-parse, `GNN-E000` bare no-result).
- Library surface: `gnn.extract.extract_to_json(path, *, strict_validation=True,
  on_error="lenient", compact=False) -> str` — never raises, always returns JSON.

Both `gnn/__init__.py` and `utils/__init__.py` re-export their names lazily
(PEP 562 `__getattr__`), so `import gnn` stays light: no submodule — and no
heavy module-scope dependency (psutil, matplotlib) — executes until a name is
resolved. The POMDP extractor (`gnn.extract.pomdp_extractor`) is usable headless with
heavy deps absent.

## Validation System

### Validation Levels

1. **BASIC** - File structure and syntax validation
2. **STANDARD** - Semantic validation + Active Inference compliance
3. **STRICT** - Cross-format consistency + research standards
4. **RESEARCH** - Complete documentation + provenance tracking
5. **ROUND_TRIP** - Format conversion validation with data preservation

```python
from gnn.schema_validator import GNNValidator, ValidationLevel

validator = GNNValidator(
    validation_level=ValidationLevel.STANDARD, enable_round_trip_testing=False
)

result = validator.validate_file("model.md")
print(f"Valid: {result.is_valid}")
print(f"Errors: {len(result.errors)}")
```

## Round-Trip Testing

### Suite status

For the reference model and the formats listed in [`round_trip_config.py`](testing/round_trip_config.py), the suite reports **100%** round-trip success. See **[SPEC.md](SPEC.md)** for how that relates to all 23 enum formats (PNML/EBNF not in the default list).

### Embedded Data Architecture

The system uses embedded data in format-specific comments to preserve model semantics during format conversion:

```python
# JSON format with embedded model data
{
    "model_name": "Example",
    "variables": [...],
    /* MODEL_DATA: {"complete":"model","data":"embedded"} */
}

# XML format with embedded preservation
<model>
    <variables>...</variables>
    <!-- MODEL_DATA: {"complete":"model","data":"embedded"} -->
</model>
```

### Usage

```python
from gnn.testing.round_trip_tester import GNNRoundTripTester

tester = GNNRoundTripTester()
report = tester.run_comprehensive_tests()

print(f"Success rate: {report.get_success_rate():.1f}%")
print(f"Tests passed: {report.successful_tests}/{report.total_tests}")
```

## Processing Capabilities

### Multi-Level Processing

```python
from gnn.mcp.processors import process_gnn_folder

success = process_gnn_folder(
    target_dir=Path("models/"),
    output_dir=Path("results/"),
    logger=logger,
    validation_level="standard",
    enable_round_trip=False,
    recursive=True,
)
```

### Cross-Format Consistency

```python
from gnn.schema_validator import CrossFormatValidator

validator = CrossFormatValidator()
result = validator.validate_cross_format_consistency(gnn_content)

print(f"Consistency rate: {result.get_consistency_rate():.1f}%")
print(f"Formats tested: {len(result.schema_formats)}")
```

## Enhanced Components

### Schema Validator

Features:

- Multiple validation levels
- Multi-format parsing with automatic detection
- Binary format support
- Performance metrics and reporting
- Cross-format semantic validation

```python
from gnn.schema_validator import GNNValidator, ValidationLevel

validator = GNNValidator(validation_level=ValidationLevel.STRICT)
result = validator.validate_file("model.md")

# Result analysis
print(f"Validation level: {result.validation_level.value}")
print(f"Format detected: {result.format_tested}")
print(f"Performance: {result.performance_metrics}")
```

### Testing Infrastructure

The `gnn/testing/round_trip_tester.py` module provides comprehensive testing:

```python
from gnn.testing.round_trip_tester import GNNRoundTripTester

tester = GNNRoundTripTester()
report = tester.run_comprehensive_tests()

# Results analysis
for result in report.round_trip_results:
    status = "PASS" if result.success else "FAIL"
    print(f"{result.target_format.value}: {status}")
```

## GNN Syntax

### Variable Definitions

```markdown
# StateSpaceBlock
A[3,3,type=float]                    # 3x3 transition matrix
s_f0[2,1,type=float]                 # Hidden state factor 0
o_m0[3,1,type=int]                   # Observation modality 0
learning_rate[1,type=float]          # Scalar learning rate
π_policy[4,2,type=categorical]       # Policy matrix (Unicode supported)
```

### Connections

```markdown
# Connections
A>B                                  # Directed influence
(A,B)-C                             # Multi-source undirected
X|Y                                  # Conditional dependency
(s_f0,s_f1)>(A_m0,A_m1,A_m2)       # Multi-variable connection
```

### Parameters

```markdown
# InitialParameterization
A=[[1.0, 0.0], [0.0, 1.0]]         # Matrix initialization
learning_rate=0.01                   # Scalar value
enabled=true                         # Boolean value
metadata={"version": "1.0"}          # Complex object
```

## Active Inference Conventions

Standard Active Inference naming patterns:

- **A matrices**: `A_m0`, `A_m1` (Likelihood/observation matrices)
- **B matrices**: `B_f0`, `B_f1` (Transition dynamics)
- **C vectors**: `C_m0`, `C_m1` (Preferences/goals)
- **D vectors**: `D_f0`, `D_f1` (Priors over initial states)
- **Hidden states**: `s_f0`, `s_f1` (State factors)
- **Observations**: `o_m0`, `o_m1` (Observation modalities)
- **Actions**: `u_c0`, `u_c1` (Control factors)
- **Policies**: `π_c0`, `π_c1` (Policy variables)

## Error Handling

### Common Error Patterns

#### Format Detection

```
Error: Could not detect format for file.unknown
Solution: Use format_hint parameter: validator.validate_file('model.txt', format_hint='markdown')
```

#### Round-Trip Issues

```
Error: Round-trip test failed for XML format: 3 semantic differences
Solution: Check embedded data preservation in XML serializer
```

#### Cross-Format Inconsistencies

```
Error: Semantic checksums differ across formats
Solution: Review format-specific serialization patterns
```

## Pipeline Integration

Integration with the broader GNN pipeline:

1. **Discovery**: Multi-format file discovery with automatic detection
2. **Type Checking**: Multi-level validation with optional round-trip testing
3. **Export**: Semantic preservation across all formats
4. **Visualization**: Format-aware graph generation
5. **Rendering**: Code generation for multiple backends

### Pipeline Usage

```python
from gnn.mcp.processors import process_gnn_folder

success = process_gnn_folder(
    target_dir=Path("models/"),
    output_dir=Path("results/"),
    logger=logger,
    validation_level="standard",
    enable_round_trip=False,
)
```

### Format Conversion

```python
from gnn.parsers import GNNParsingSystem

system = GNNParsingSystem(strict_validation=False)
output = system.convert_file("model.md", "model.json")
# Format inferred from extensions; pass to_format=/from_format= to override.
```

Content-based format detection (no filename hint needed) is available via
`gnn.parsers.unified_parser.detect_gnn_format_from_content`.

## Performance

### Benchmarks

- **File Processing**: 50+ files/second with full validation
- **Round-Trip Testing**: 21 formats (see `testing/round_trip_config.py`); timing varies per model — treat any fixed duration as a spot measurement, not a constant
- **Cross-Format Validation**: Sub-second consistency checks
- **Memory Usage**: <100MB for complex multi-format models

### Performance Monitoring

```python
result = validator.validate_file("model.md")
metrics = result.performance_metrics

print(f"Validation time: {metrics.get('validation_time', 0):.3f}s")
print(f"Content length: {metrics.get('content_length', 0)} chars")
```

## Development

### Adding Validation Rules

```python
class CustomGNNValidator(GNNValidator):
    def _validate_custom_requirements(self, parsed_gnn, result):
        if not parsed_gnn.ontology_mappings:
            result.suggestions.append("Consider adding ontology mappings")


validator = CustomGNNValidator(validation_level=ValidationLevel.STRICT)
```

### Supporting New Formats

```python
from gnn.parsers.common import BaseGNNParser


class NewFormatParser(BaseGNNParser):
    def get_supported_extensions(self) -> List[str]:
        return [".newext"]

    def parse_file(self, file_path: str) -> ParseResult:
        return self._parse_with_embedded_data(file_path)


# Register with system
parsing_system.register_parser(GNNFormat.NEW_FORMAT, NewFormatParser)
```

## Documentation

### Available Resources

- **`testing/README_round_trip.md`**: Testing methodology and results
- **`testing/alignment_status.md`**: Format compatibility status
- **Format-specific guides**: Documentation for each supported format
- **Performance guides**: Optimization best practices
- **[SPEC.md](SPEC.md)**: Canonical format counts and architecture

## Summary

The GNN module provides infrastructure for Active Inference model specification: **23** `GNNFormat` values, **22** serializers, and a round-trip test suite (see SPEC.md) that achieves **100%** pass rate for its configured formats. Key features include multi-level validation, cross-format consistency checking, and round-trip testing with embedded model data where formats allow it.

## License and Citation

This implementation follows the GNN specification v1.0+ and is part of the GeneralizedNotationNotation project. See the main repository for license and citation information.

## References

- Project overview: ../../README.md
- Comprehensive docs: ../../DOCS.md
- Architecture guide: ../../ARCHITECTURE.md
- Pipeline details: ../../docs/pipeline/README.md

## Documentation
- **[README](README.md)**: Module Overview
- **[AGENTS](AGENTS.md)**: Agentic Workflows
- **[SPEC](SPEC.md)**: Architectural Specification
- **[SKILL](SKILL.md)**: Capability API
