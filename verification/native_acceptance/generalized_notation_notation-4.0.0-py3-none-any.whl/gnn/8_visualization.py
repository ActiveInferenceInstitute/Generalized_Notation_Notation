#!/usr/bin/env python3
"""
Step 8: Visualization Processing (Thin Orchestrator)

This step handles visualization processing for GNN files with comprehensive
safe-to-fail patterns and robust output management.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/visualization/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the visualization module.

Pipeline Flow:
    main.py → 8_visualization.py (this script) → visualization/ (modular implementation)

How to run:
  uv run python src/gnn/8_visualization.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - Visualization results in the specified output directory
  - Matrix visualizations, network graphs, and combined analysis plots
  - Comprehensive visualization reports and summaries
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that visualization dependencies are installed
  - Check that src/gnn/visualization/ contains visualization modules
  - Check that the output directory is writable
  - Verify visualization configuration and requirements
"""

from typing import cast

from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)
from gnn.visualization import process_visualization

# Create the standardized pipeline script
run_script = create_standardized_pipeline_script(
    "8_visualization.py",
    process_visualization,
    "Matrix and network visualization processing",
)


def main() -> int:
    """Main entry point for the visualization step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
