"""
Analysis module for GNN Processing Pipeline.

This module provides comprehensive analysis and statistical processing for GNN models.
"""

from typing import Any, Dict

from gnn import __version__

FEATURES: dict[str, Any] = {
    "statistical_analysis": True,
    "framework_comparison": True,
    "post_simulation_analysis": True,
    "belief_visualization": True,
    "cross_framework_metrics": True,
    "pytorch_analysis": True,
    "numpyro_analysis": True,
    "mcp_integration": True,
}

# Phase 6: analysis submodules are in-tree; all deps (numpy, matplotlib) are
# core per pyproject.toml. Unconditional imports; any ImportError is a real
# bug that must surface in CI rather than be hidden by substitute classes.
from .analyzer import (
    analyze_distributions,
    analyze_framework_outputs,
    calculate_cognitive_complexity,
    calculate_complexity_metrics,
    calculate_connection_statistics,
    calculate_correlations,
    calculate_cyclomatic_complexity,
    calculate_maintainability_index,
    calculate_section_statistics,
    calculate_structural_complexity,
    calculate_technical_debt,
    calculate_variable_statistics,
    extract_connections,
    extract_sections,
    extract_variables,
    generate_analysis_summary,
    generate_framework_comparison_report,
    perform_model_comparisons,
    perform_statistical_analysis,
    run_performance_benchmarks,
    visualize_cross_framework_metrics,
)
from .complexity import estimate_model_complexity, to_json_text
from .post_simulation import (
    analyze_active_inference_metrics,
    analyze_execution_results,
    analyze_free_energy,
    analyze_policy_convergence,
    analyze_simulation_traces,
    analyze_state_distributions,
    animate_belief_evolution,
    compare_framework_results,
    compute_expected_free_energy,
    compute_information_gain,
    compute_kl_divergence,
    # Active Inference-specific statistical methods
    compute_shannon_entropy,
    compute_variational_free_energy,
    extract_activeinference_jl_data,
    extract_discopy_data,
    extract_jax_data,
    extract_jax_kronecker_data,
    extract_pymdp_data,
    extract_rxinfer_data,
    generate_action_analysis,
    generate_belief_heatmaps,
    generate_cross_framework_comparison,
    generate_free_energy_plots,
    generate_observation_analysis,
    plot_belief_evolution,
    # Comprehensive visualization functions
    visualize_all_framework_outputs,
)
from .processor import convert_numpy_types, process_analysis

# Note: framework-specific analyzers live in ``src/gnn/analysis/<framework>/analyzer.py``
# and are discovered by ``processor.process_analysis`` via ``importlib`` — no
# need to re-export per-framework aliases at the package level.


def check_analysis_tools() -> Dict[str, Dict[str, Any]]:
    """Check availability of analysis tools."""
    import importlib

    tools: dict[Any, Any] = {}
    for pkg_name in ("numpy", "pandas", "scipy", "matplotlib"):
        try:
            m = importlib.import_module(pkg_name)
            tools[pkg_name] = {"available": True, "version": m.__version__}
        except ImportError:
            tools[pkg_name] = {"available": False, "version": None}
    return tools


__all__: list[Any] = [
    "__version__",
    "FEATURES",
    "process_analysis",
    "convert_numpy_types",
    "perform_statistical_analysis",
    "extract_variables",
    "extract_connections",
    "extract_sections",
    "calculate_variable_statistics",
    "calculate_connection_statistics",
    "calculate_section_statistics",
    "analyze_distributions",
    "calculate_correlations",
    "calculate_cyclomatic_complexity",
    "calculate_cognitive_complexity",
    "calculate_structural_complexity",
    "calculate_complexity_metrics",
    "calculate_maintainability_index",
    "calculate_technical_debt",
    "run_performance_benchmarks",
    "perform_model_comparisons",
    "generate_analysis_summary",
    "analyze_framework_outputs",
    "generate_framework_comparison_report",
    "visualize_cross_framework_metrics",
    # Post-simulation analysis functions
    "analyze_simulation_traces",
    "analyze_free_energy",
    "analyze_policy_convergence",
    "analyze_state_distributions",
    "compare_framework_results",
    "extract_pymdp_data",
    "extract_rxinfer_data",
    "extract_activeinference_jl_data",
    "extract_jax_data",
    "extract_jax_kronecker_data",
    "extract_discopy_data",
    "analyze_execution_results",
    # Active Inference-specific statistical methods
    "compute_shannon_entropy",
    "compute_kl_divergence",
    "compute_variational_free_energy",
    "compute_expected_free_energy",
    "compute_information_gain",
    "analyze_active_inference_metrics",
    # Comprehensive visualization functions
    "visualize_all_framework_outputs",
    "generate_belief_heatmaps",
    "generate_action_analysis",
    "generate_free_energy_plots",
    "generate_observation_analysis",
    "generate_cross_framework_comparison",
    "plot_belief_evolution",
    "animate_belief_evolution",
    # Wave-8 static complexity estimator (pure-stdlib subpackage)
    "estimate_model_complexity",
    "to_json_text",
]


def get_module_info() -> dict[str, Any]:
    """Return module metadata for composability and MCP discovery."""
    return {
        "name": "analysis",
        "version": __version__,
        "description": "Statistical analysis and result aggregation for GNN pipeline outputs",
        "features": FEATURES,
    }
