# JAX Analysis — Technical Specification

**Version**: [pyproject.toml](../../../../pyproject.toml) (canonical)

## Input

- `simulation_results.json` from JAX execution step
- JAX tensor outputs and computation traces

## Output

- Belief trajectory plots (PNG)
- Gradient analysis visualizations (PNG)
- Performance benchmarks (JSON)
- Returns the list of generated visualization file paths; no `analysis_summary.json` is written

## Framework

- JAX numerical results parsed from JSON/numpy
- Matplotlib and seaborn visualization

## Analysis Types

- Belief convergence analysis
- Gradient norm tracking
- Computational performance profiling

## Error Handling

- Missing JAX results → warning + empty analysis
- Numerical instability → clamp values and warn
