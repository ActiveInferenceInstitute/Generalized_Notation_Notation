#!/usr/bin/env python3
"""
Step 4: Model Registry Processing (Thin Orchestrator)

This step implements a centralized model registry for GNN models with versioning,
metadata management, and model lifecycle tracking.

Architectural Role:
    This is a "thin orchestrator" - a minimal script that delegates core functionality
    to the corresponding module (src/gnn/model_registry/). It handles argument parsing, logging
    setup, and calls the actual processing functions from the model_registry module.

Pipeline Flow:
    main.py → 4_model_registry.py (this script) → model_registry/ (modular implementation)

How to run:
  uv run python src/gnn/4_model_registry.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - Model registry data in the specified output directory
  - Model metadata and versioning information
  - Registry summary and processing reports
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that model registry dependencies are installed
  - Check that src/gnn/model_registry/ contains registry modules
  - Check that the output directory is writable
  - Verify model registry configuration and requirements
"""

from typing import cast

from gnn.model_registry import process_model_registry
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "4_model_registry.py",
    process_model_registry,
    "Model registry processing for GNN models",
    additional_arguments={
        "registry_path": {"type": str, "help": "Path to model registry file"},
        "query_ontology": {
            "type": str,
            "help": "Filter registered models by ontology concept substring",
        },
    },
)


def main() -> int:
    """Main entry point for the model registry step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
