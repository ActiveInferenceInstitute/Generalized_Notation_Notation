#!/usr/bin/env python3
"""
Step 10: Ontology Processing (Thin Orchestrator)

This step orchestrates ontology processing and validation for GNN models.
It is a thin orchestrator that delegates core functionality to the ontology module.

How to run:
  uv run python src/gnn/10_ontology.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)

Expected outputs:
  - Ontology processing results in the specified output directory
  - Ontology validation and compliance reports
  - Term mapping and relationship analysis
  - Actionable error messages if dependencies or paths are missing
  - Clear logging of all resolved arguments and paths

If you encounter errors:
  - Check that ontology dependencies are installed
  - Check that src/gnn/ontology/ contains ontology modules
  - Check that the output directory is writable
  - Verify ontology configuration and term mapping setup
"""

from pathlib import Path
from typing import cast

# Hard import: ontology is a core module and must always be available.
from gnn.ontology import process_ontology
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "10_ontology.py",
    process_ontology,
    "Ontology processing and validation for GNN models",
    additional_arguments={
        "ontology_terms_file": {
            "type": Path,
            "help": "Path to ontology terms JSON file",
            "flag": "--ontology-terms-file",
        }
    },
)


def main() -> int:
    """Main entry point for the ontology step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
