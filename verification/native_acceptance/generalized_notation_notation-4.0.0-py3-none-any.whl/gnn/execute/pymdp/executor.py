#!/usr/bin/env python3
"""
PyMDP Executor module for GNN Processing Pipeline.

This module provides PyMDP simulation execution capabilities.
"""

import logging
import traceback
from pathlib import Path
from typing import Any, Dict, Tuple

logger = logging.getLogger(__name__)


def execute_pymdp_simulation_from_gnn(
    gnn_spec: Dict[str, Any], output_dir: Path, correlation_id: str = ""
) -> Tuple[bool, Dict[str, Any]]:
    """
    Execute PyMDP simulation from GNN specification.

    Wraps execute_pymdp_simulation with correlation-ID logging and unified
    exception handling so callers get a structured error on any failure.

    Args:
        gnn_spec: GNN specification dictionary
        output_dir: Output directory for results
        correlation_id: Correlation ID for tracking

    Returns:
        Tuple of (success, results)
    """
    try:
        logger.info(
            f"Starting PyMDP simulation from GNN spec (correlation_id: {correlation_id})"
        )

        # Execute simulation
        success, results = execute_pymdp_simulation(
            gnn_spec, output_dir, correlation_id
        )

        if success:
            logger.info(
                f"PyMDP simulation completed successfully (correlation_id: {correlation_id})"
            )
        else:
            logger.error(f"PyMDP simulation failed (correlation_id: {correlation_id})")

        return success, results

    except Exception as e:
        logger.error(f"PyMDP simulation execution failed: {e}")
        return False, {"error": str(e), "traceback": traceback.format_exc()}


def execute_pymdp_simulation(
    gnn_spec: Dict[str, Any], output_dir: Path, correlation_id: str = ""
) -> Tuple[bool, Dict[str, Any]]:
    """
    Execute PyMDP simulation using the canonical pymdp 1.0.0 runner.

    Args:
        gnn_spec: GNN specification dictionary
        output_dir: Output directory for results
        correlation_id: Correlation ID for tracking

    Returns:
        Tuple of (success, results)
    """
    try:
        logger.info(f"Executing PyMDP simulation (correlation_id: {correlation_id})")

        from .simulation import run_pymdp_simulation

        success, results = run_pymdp_simulation(gnn_spec, output_dir)

        if success:
            logger.info("PyMDP simulation completed successfully")
            results["correlation_id"] = correlation_id
            return True, results
        else:
            logger.error(f"PyMDP simulation failed: {results.get('error', 'Unknown')}")
            results["correlation_id"] = correlation_id
            return False, results

    except Exception as e:
        logger.error(f"PyMDP simulation execution failed: {e}")
        import traceback

        return False, {
            "success": False,
            "error": str(e),
            "traceback": traceback.format_exc(),
            "correlation_id": correlation_id,
        }
