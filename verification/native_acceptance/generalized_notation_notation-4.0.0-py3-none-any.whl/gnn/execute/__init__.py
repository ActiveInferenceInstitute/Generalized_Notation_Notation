"""
execute module for GNN Processing Pipeline.

Provides simulation execution across ten backends — PyMDP, RxInfer.jl,
ActiveInference.jl, JAX, DisCoPy, PyTorch, NumPyro, Stan, Lean (via the
fep_lean bridge), and bnlearn — plus the dependency/environment validators
that gate them.
"""

from typing import Any

from gnn import __version__

FEATURES: dict[str, Any] = {
    "pymdp_execution": True,
    "rxinfer_execution": True,
    "activeinference_jl_execution": True,
    "discopy_execution": True,
    "jax_execution": True,
    "numpyro_execution": True,
    "bnlearn_execution": True,
    "validation": True,
    "mcp_integration": True,
}

from pathlib import Path
from typing import Any, Dict, List

# Constrained type for supported execution framework names — the canonical
# Literal lives in ``execute.types``; re-exported here for the public name.
# All execute submodules are in-tree — their import must succeed or tests
# catch it. Any ImportError here is a real bug, not a "missing optional dep"
# situation, and should fail loudly.
from .doctor import collect_doctor_report
from .executor import (
    GNNExecutor,
    clear_execution_cache,
    execute_gnn_model,
    execute_script_safely,
    list_frameworks,
    run_simulation,
)
from .planning import plan_execute
from .processor import execute_simulation_from_gnn, process_execute
from .pymdp import (
    PyMDPSimulation,
    execute_pymdp_simulation,
    execute_pymdp_simulation_from_gnn,
    get_pymdp_health_status,
    validate_pymdp_environment,
)

# Constrained type for supported execution framework names — the canonical
# Literal lives in ``execute.types``; re-exported here for the public name.
from .types import ExecutionFrameworkName as FrameworkName
from .validator import (
    check_dependencies,
    check_file_permissions,
    check_network_connectivity,
    check_python_environment,
    check_system_resources,
    log_validation_results,
    validate_execution_environment,
)

__all__: list[Any] = [
    "__version__",
    "FEATURES",
    "FrameworkName",
    # Core classes
    "GNNExecutor",
    "PyMDPSimulation",
    # Execution functions
    "process_execute",
    "execute_simulation_from_gnn",
    "execute_gnn_model",
    "run_simulation",
    "execute_script_safely",
    "clear_execution_cache",
    # Introspection / planning
    "list_frameworks",
    "plan_execute",
    "collect_doctor_report",
    "execute_pymdp_simulation_from_gnn",
    "execute_pymdp_simulation",
    "validate_pymdp_environment",
    "get_pymdp_health_status",
    # Validation
    "validate_execution_environment",
    "log_validation_results",
    "check_python_environment",
    "check_system_resources",
    "check_dependencies",
    "check_file_permissions",
    "check_network_connectivity",
]


def get_module_info() -> dict:
    """Return module metadata for composability and MCP discovery."""
    return {
        "name": "execute",
        "version": __version__,
        "description": "Multi-framework execution of rendered simulation scripts",
        "features": FEATURES,
    }
