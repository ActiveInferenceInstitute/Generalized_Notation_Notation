"""
JAX Executor for GNN Processing Pipeline

This module provides comprehensive execution capabilities for JAX POMDP scripts
generated from GNN specifications, including device selection, performance monitoring,
and benchmarking.

@Web: https://github.com/google/jax
@Web: https://optax.readthedocs.io
@Web: https://flax.readthedocs.io
@Web: https://pfjax.readthedocs.io
"""

from typing import Any

from .jax_runner import (
    execute_jax_script,
    find_jax_scripts,
    is_jax_available,
    run_jax_scripts,
)
from .kronecker_executor import (
    execute_kronecker_factorized,
    run_kronecker_factorized_execution,
)

__all__: list[Any] = [
    "run_jax_scripts",
    "execute_jax_script",
    "find_jax_scripts",
    "is_jax_available",
    "run_kronecker_factorized_execution",
    "execute_kronecker_factorized",
]
