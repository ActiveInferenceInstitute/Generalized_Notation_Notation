# GNN In-Repo Documentation

Technical documentation subtree for the GNN pipeline.

## Contents

- **[cognitive_phenomena/](cognitive_phenomena/)** — Cognitive phenomena relevant to Active Inference modeling
  - `effort/` — Cognitive effort models
  - `memory/` — Temporal memory dynamics

## Purpose

Provides theoretical background, design rationale, and reference material for GNN model designers and pipeline contributors.

## See Also

- [src/gnn/AGENTS.md](../AGENTS.md) — Pipeline module registry
- [src/gnn/SPEC.md](../SPEC.md) — Pipeline specification
- [docs/gnn/](../../../docs/gnn/) — External GNN documentation hub
