#!/usr/bin/env python3
"""
Step 9: Advanced Visualization (Thin Orchestrator)

This step delegates advanced visualization processing to the module implementation.

How to run:
  uv run python src/gnn/9_advanced_viz.py --target-dir input/gnn_files --output-dir output --verbose
  uv run python src/gnn/main.py  # (runs as part of the pipeline)
"""

from typing import cast

from gnn.advanced_visualization import VIZ_TYPE_CHOICES, process_advanced_viz
from gnn.utils.pipeline_orchestration.pipeline_template import (
    create_standardized_pipeline_script,
)

run_script = create_standardized_pipeline_script(
    "9_advanced_viz.py",
    process_advanced_viz,
    "Advanced visualization and exploration with safe-to-fail patterns",
    additional_arguments={
        "viz_type": {
            "type": str,
            "choices": list(VIZ_TYPE_CHOICES),
            "default": "all",
            "help": "Type of visualization to generate: all, 3d, interactive, dashboard, d2/diagrams (D2 diagrams), pipeline (pipeline D2 diagrams), statistical (statistical plots and correlations), pomdp (POMDP-specific visualizations), network (network analysis)",
        },
        "interactive": {
            "type": bool,
            "default": True,
            "help": "Generate interactive visualizations",
        },
        "export_formats": {
            "type": str,
            "nargs": "+",
            "default": ["html", "json"],
            "help": "Export formats",
        },
    },
)


def main() -> int:
    """Main entry point for advanced visualization step."""
    return cast("int", run_script())


if __name__ == "__main__":
    raise SystemExit(main())
